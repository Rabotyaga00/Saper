document.addEventListener('DOMContentLoaded', () => {
const bomb = document.querySelectorAll('.item_closed');
let count = 0;
bomb.forEach(item_closed => {
    item_closed.addEventListener('click', () => {
        if (!item_closed.classList.contains('item_bomb')) {
            count +=1;
            item_closed.classList.toggle('item_closed');
                item_closed.classList.add('item_open'); 
                if (count === 15) {
                    alert('Победа!');
                    bomb.forEach(otherField => {
                        otherField.classList.add('disabled'); 
                    });
                }
}}, { once: true });
});
const gameover = document.querySelectorAll('.item_bomb');

gameover.forEach(field => {
    field.addEventListener('click', () => {
        alert('Game Over!');
        bomb.forEach(otherField => {
            otherField.classList.add('disabled');
        });
    });
});
});